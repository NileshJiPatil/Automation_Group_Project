package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NopCommerce_MainClass {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Automation Teating Edubridge\\nopcommerce_SeleniumProject\\BrowserExtention\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
        NopCommerce nc= new NopCommerce();	
        nc.maximizeBrowser(driver);
	    nc.getUrl(driver);
	    Thread.sleep(2000);
	    nc.clickLogin(driver);
	    Thread.sleep(2000);
	    nc.enterUsername(driver,"mitai.swathi@outlook.com");
	    Thread.sleep(2000);
	    nc.enterPassword(driver,"Swathi@09");
	    Thread.sleep(2000);
	    nc.clickOnLogin(driver);
	    Thread.sleep(2000);
	    nc.clickOnLogout(driver);
	    Thread.sleep(2000);
	    nc.closeBrowser(driver);
	}

}

