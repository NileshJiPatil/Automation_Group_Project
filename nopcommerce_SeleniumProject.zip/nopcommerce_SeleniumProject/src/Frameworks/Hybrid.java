package Frameworks;

public class Hybrid {

}
