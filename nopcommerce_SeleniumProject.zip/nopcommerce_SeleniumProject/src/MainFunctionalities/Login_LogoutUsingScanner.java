package MainFunctionalities;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_LogoutUsingScanner {

	public static void main(String[] args) throws Exception {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the email");
		String em=sc.next();
		System.out.println("Enter the password");
		String pwd=sc.next();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Automation Teating Edubridge\\nopcommerce_SeleniumProject\\BrowserExtention\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
	  	driver.manage().deleteAllCookies();	
		driver.get("https://demo.nopcommerce.com/");
		// click on log in link
		driver.findElement(By.xpath("//a[@class='ico-login']")).click();
		// enter the email
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys(em);
		Thread.sleep(2000);
		// enter the password
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys(pwd);
		Thread.sleep(2000);
		// click on login button
		driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();
		Thread.sleep(2000);
		
		// log out the page
		driver.findElement(By.xpath("//a[@class='ico-logout']")).click();
		Thread.sleep(2000);
		// close the driver
		driver.close();
		
		
	}

}
