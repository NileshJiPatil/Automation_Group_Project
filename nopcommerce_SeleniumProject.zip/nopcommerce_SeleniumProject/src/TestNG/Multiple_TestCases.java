package TestNG;

public class Multiple_TestCases {

}
