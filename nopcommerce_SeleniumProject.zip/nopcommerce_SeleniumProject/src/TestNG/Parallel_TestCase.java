package TestNG;

public class Parallel_TestCase {

}
