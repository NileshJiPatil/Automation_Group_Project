package BasicProgram;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTesting {

	
		public static void main(String[] args) throws InterruptedException    {
			Scanner s= new Scanner(System.in);
			System.out.println("\n Enter 1 for GOOGLE CHROME.\n Enter 2 for MICROSOFT EDGE.\n Enter 3 for MOZELA FIRFOX");
			int input =s.nextInt();
			WebDriver driver=null;
			switch(input)
			{
			case 1:
				//System.setProperty("wbdriver.chrome.driver", "\"C:\\\\Users\\\\Admin\\\\Desktop\\\\Automation Teating Edubridge\\\\Automation testing\\\\Browser extension\\\\chromedriver.exe\");
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Automation Teating Edubridge\\Automation testing\\Browser extension\\chromedriver.exe");
			  	  driver = new ChromeDriver();
			  	  break;
			case 2:
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Automation Teating Edubridge\\Automation testing\\Browser extension\\msedgedriver.exe");
			  	  driver = new EdgeDriver();
			  	  break;
			case 3:
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Automation Teating Edubridge\\Automation testing\\Browser extension\\geckodriver.exe");
			  	  driver = new FirefoxDriver();
			  	  break;
			}
			driver.manage().window().maximize();
		  	driver.manage().deleteAllCookies();
		  //URL
			driver.get("https://demo.nopcommerce.com/");
			Thread.sleep(2000);


			//click on login 
			driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			Thread.sleep(2000);

			//Username
			driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("mitai.swathi@outlook.com");
			Thread.sleep(2000);

			//Password
			driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("Swathi@12345");
			Thread.sleep(6000);

			//login
			driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
			Thread.sleep(2000);

			//Logout
			driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			Thread.sleep(2000);

			driver.close();


		}



		
		

	}


